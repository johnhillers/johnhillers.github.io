from flask import Flask, jsonify
import requests
from bs4 import BeautifulSoup
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
app = Flask(__name__)

@app.route("/get-sonar-data", methods=["GET"])
def get_sonar_data():
    try:
        url = "https://sonar.surf/"
        headers = {"User-Agent": "Mozilla/5.0"}
        res = requests.get(url, headers=headers, verify=False)

        soup = BeautifulSoup(res.text, "html.parser")
        title = soup.title.string if soup.title else "No title found"

        return jsonify({"page_title": title})
    except Exception as e:
        print("Error:", e)
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
